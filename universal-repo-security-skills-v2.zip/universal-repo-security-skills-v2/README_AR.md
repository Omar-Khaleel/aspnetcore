# Universal Repository Security Skills v2 — أمر واحد لفحص الريبو

هذه النسخة مصممة لطريقتك تحديدًا: تعمل Fork للريبو، تربطه بـCodex، ثم ترسل **أمرًا واحدًا فقط**:

```text
$repo-audit
```

السكيل الرئيسي يحتوي داخله جميع التعليمات الافتراضية، ويقوم تلقائيًا بـ:

1. تثبيت الـcommit الحقيقي للمنتج قبل إضافة السكيلز.
2. إنشاء خريطة كاملة للريبو وحدود الثقة والصلاحيات.
3. بناء Threat Model خاص بالمشروع.
4. البحث المنهجي عن مرشحي الثغرات.
5. إنشاء PoC معزول وإثبات إيجابي وضوابط سلبية.
6. محاولة إسقاط كل مرشح كترياج عدائي.
7. العودة للاختبار لسدّ الثغرات في الأدلة وإعادة الترياج حتى أربع دورات.
8. البحث عن variants للسبب الجذري.
9. إنشاء التقرير، ثم مهاجمة **نص التقرير نفسه** وإعادة مراجعته حتى ثلاث مرات.
10. إخراج تقرير نهائي فقط عندما لا يبقى اعتراض جوهري غير محلول.

إذا انتهت جلسة Codex بسبب حدود الوقت أو السياق، ترسل نفس الأمر مرة أخرى فقط:

```text
$repo-audit
```

وسيقرأ `.security-audit/state.json` ويكمل من آخر مرحلة بدل إعادة العمل.

## السكيلز

- `repo-audit`: المشرف الكامل؛ هو الأمر الذي تستخدمه عادةً.
- `repo-map`: الخريطة فقط، ويعمل دون برومبت إضافي.
- `repo-threat-model`: نموذج التهديد فقط، ويشغّل الخريطة تلقائيًا إن كانت ناقصة.
- `repo-hunt`: البحث فقط، ويشغّل المتطلبات الناقصة تلقائيًا.
- `repo-validate`: يختار المرشحين حسب الأولوية وينشئ PoCs ويصنفهم.
- `repo-triage`: يحارب جميع النتائج ويعيدها للاختبار عند وجود فجوة قابلة للحسم.
- `repo-report`: يكتب تقارير النتائج REPORTABLE ثم يهاجم نص التقرير ويعدّله.

## الطريقة الموصى بها مع Fork وCodex Web

بعد فك الحزمة، من جهازك المحلي شغّل:

```bash
chmod +x install-into-repo.sh
./install-into-repo.sh /path/to/YOUR_FORK
```

سيتم إنشاء:

```text
YOUR_FORK/
├── .agents/skills/
│   ├── repo-audit/
│   ├── repo-map/
│   ├── repo-threat-model/
│   ├── repo-hunt/
│   ├── repo-validate/
│   ├── repo-triage/
│   └── repo-report/
└── AGENTS.md
```

ملف `AGENTS.md` لا يحتوي منهجية الفحص؛ هو مجرد مسار احتياطي صغير يوجّه Codex لقراءة السكيل الرئيسي، لأن Codex Cloud يقرأ تعليمات الريبو تلقائيًا. التعليمات الكاملة تبقى داخل السكيلز.

ثم:

```bash
cd /path/to/YOUR_FORK
git checkout -b security-audit
git add .agents/skills AGENTS.md
git commit -m "Add autonomous repository security audit skills"
git push -u origin security-audit
```

في Codex Web اختر الـFork وفرع `security-audit`، ثم أرسل:

```text
$repo-audit
```

لا تحتاج إلى كتابة Mode أو MSRC أو تعليمات PoC أو الترياج. الافتراضات الداخلية هي: `deep`، تقرير نهائي بالإنجليزية، اختبارات محلية معزولة، وتحديد برنامج الإفصاح من `SECURITY.md` والمصادر الرسمية المتاحة.

## تثبيت شخصي لـCodex CLI / IDE / Desktop

```bash
chmod +x install.sh
./install.sh codex
```

المسار:

```text
~/.agents/skills/
```

ثم افتح Codex داخل أي ريبو وأرسل:

```text
$repo-audit
```

## أوامر المراحل المنفردة

جميعها تعمل الآن دون شرح إضافي:

```text
$repo-map
$repo-threat-model
$repo-hunt
$repo-validate
$repo-triage
$repo-report
```

لكن الاستخدام المعتاد هو `$repo-audit` فقط؛ فهو يستدعي المنهجيات الأخرى داخليًا.

## مساحة العمل

```text
.security-audit/
├── 00-scope.md
├── 01-inventory.json
├── 02-architecture.md
├── 03-threat-model.md
├── 04-attack-surface.md
├── 05-candidates.json
├── 06-evidence/
├── 07-triage.md
├── 08-coverage.md
├── 09-final-summary.md
├── reports/
├── lab/
└── state.json
```

أضفها إلى `.git/info/exclude` أو `.gitignore` إذا لم ترغب برفع الأدلة إلى GitHub.

## كيف تعمل حلقة الإسقاط؟

لكل مرشح:

```text
PoC وإثبات
   ↓
أقوى اعتراض كترياج
   ↓
تجربة صغيرة تحسم الاعتراض
   ↓
إعادة الاختبار
   ↓
إعادة الترياج من الصفر
   ↓
REPORTABLE أو REJECTED أو NEEDS_ENVIRONMENT أو VALIDATED_NON_REPORTABLE
```

ولكل تقرير REPORTABLE:

```text
مسودة تقرير
   ↓
مهاجمة نص التقرير نفسه
   ↓
ربط كل ادعاء بدليل
   ↓
حذف التضخيم وسد النقص
   ↓
إعادة الترياج
   ↓
تقرير نهائي أو Gap Memo
```

الحلقات محدودة ومبنية على الأدلة: أربع دورات للمرشح وثلاث مراجعات للتقرير. الغرض ليس تحسين الكلام فقط، بل إجراء اختبارات تحسم الاعتراض. إذا بقي اعتراض جوهري، لا يُصدر تقرير ضعيف.

## قيود مهمة

- الحزمة للفحص الدفاعي المصرح به وللاختبارات المحلية أو البيئات المخصصة فقط.
- ملكية الريبو من Microsoft أو Google لا تعني تلقائيًا أنه داخل برنامج مكافآت.
- لا يوجد سكيل يضمن العثور على ثغرة أو قبول التقرير.
- الريبو الضخم قد يحتاج أكثر من جلسة Codex؛ الأمر المطلوب للاستئناف يبقى `$repo-audit` فقط.
- لا يتم تحويل crash أو scanner alert أو self-attack إلى ثغرة بالقوة.
