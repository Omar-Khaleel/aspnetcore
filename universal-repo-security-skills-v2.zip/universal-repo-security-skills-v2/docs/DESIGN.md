# Design

## Goal

Make a complete repository security audit invokable through one command while preserving evidence discipline and resumability.

## Architecture

`repo-audit` is the sole orchestrator. Sibling skills are self-contained stages and may also be invoked independently without long prompts.

The workflow persists state under `.security-audit/`, separates the product baseline from audit-only commits, and uses two closed loops:

1. Candidate evidence loop: validate → hostile triage → decisive experiment → re-triage, maximum four rounds.
2. Report text loop: draft → hostile review → claim/evidence audit → revision → final triage, maximum three revisions.

## Reliability principles

- zero-prompt defaults;
- explicit authorization boundary;
- progressive disclosure through sibling skills and references;
- subagents for independent read-heavy work;
- no report before impact and reportability gates;
- no infinite loops or rhetorical polishing without new evidence;
- resumable execution from state.json;
- AGENTS.md routing fallback for repository/cloud use.
