#!/usr/bin/env bash
set -euo pipefail

MODE="${1:-both}"
SKILLS=(repo-audit repo-map repo-threat-model repo-hunt repo-validate repo-triage repo-report)

remove_from() {
  local dest="$1"
  for name in "${SKILLS[@]}"; do
    if [ -e "$dest/$name" ]; then
      rm -rf "$dest/$name"
      echo "Removed $dest/$name"
    fi
  done
}

case "$MODE" in
  codex) remove_from "$HOME/.agents/skills" ;;
  claude) remove_from "$HOME/.claude/skills" ;;
  both)
    remove_from "$HOME/.agents/skills"
    remove_from "$HOME/.claude/skills"
    ;;
  *) echo "Usage: $0 [codex|claude|both]" >&2; exit 2 ;;
esac
