#!/usr/bin/env bash
set -euo pipefail

MODE="${1:-codex}"
SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/skills"

install_to() {
  local dest="$1"
  mkdir -p "$dest"
  for skill in "$SOURCE_DIR"/*; do
    [ -d "$skill" ] || continue
    local name
    name="$(basename "$skill")"
    rm -rf "$dest/$name"
    cp -R "$skill" "$dest/$name"
    echo "Installed $name -> $dest/$name"
  done
}

case "$MODE" in
  codex)
    install_to "$HOME/.agents/skills"
    ;;
  claude)
    install_to "$HOME/.claude/skills"
    ;;
  both)
    install_to "$HOME/.agents/skills"
    install_to "$HOME/.claude/skills"
    ;;
  *)
    echo "Usage: $0 [codex|claude|both]" >&2
    exit 2
    ;;
esac

echo "Done. Restart the client if skill changes do not appear immediately."
