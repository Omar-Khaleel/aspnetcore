#!/usr/bin/env bash
set -euo pipefail

REPO="${1:-.}"
SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/skills"
REPO="$(cd "$REPO" && pwd)"
DEST="$REPO/.agents/skills"

if [ ! -d "$REPO/.git" ] && ! git -C "$REPO" rev-parse --show-toplevel >/dev/null 2>&1; then
  echo "Target is not a Git repository: $REPO" >&2
  exit 2
fi

mkdir -p "$DEST"
for skill in "$SOURCE_DIR"/*; do
  [ -d "$skill" ] || continue
  name="$(basename "$skill")"
  rm -rf "$DEST/$name"
  cp -R "$skill" "$DEST/$name"
  echo "Installed $name -> $DEST/$name"
done

AGENTS="$REPO/AGENTS.md"
BEGIN='<!-- BEGIN UNIVERSAL-REPO-SECURITY-SKILLS -->'
END='<!-- END UNIVERSAL-REPO-SECURITY-SKILLS -->'
BLOCK=$(cat <<'EOF'
<!-- BEGIN UNIVERSAL-REPO-SECURITY-SKILLS -->
## Autonomous repository security audit routing

When the user invokes `$repo-audit` or asks for the complete repository security audit workflow, read and follow `.agents/skills/repo-audit/SKILL.md`. The skill contains all defaults and must execute the full map → threat model → hunt → isolated validation → adversarial triage → variant analysis → report red-team workflow. Do not ask the user to paste the long audit prompt. Resume from `.security-audit/state.json` when present.

For explicit stage invocations, read the matching `.agents/skills/<skill-name>/SKILL.md`.
<!-- END UNIVERSAL-REPO-SECURITY-SKILLS -->
EOF
)

if [ -f "$AGENTS" ]; then
  python - "$AGENTS" "$BEGIN" "$END" "$BLOCK" <<'PY'
from pathlib import Path
import sys
p = Path(sys.argv[1])
begin, end, block = sys.argv[2], sys.argv[3], sys.argv[4]
text = p.read_text(encoding='utf-8')
if begin in text and end in text:
    start = text.index(begin)
    finish = text.index(end, start) + len(end)
    text = text[:start] + block + text[finish:]
else:
    text = text.rstrip() + "\n\n" + block + "\n"
p.write_text(text, encoding='utf-8')
PY
else
  printf '%s\n' "$BLOCK" > "$AGENTS"
fi

echo "Updated routing block -> $AGENTS"
echo "Commit .agents/skills and AGENTS.md to the fork, then invoke: \$repo-audit"
